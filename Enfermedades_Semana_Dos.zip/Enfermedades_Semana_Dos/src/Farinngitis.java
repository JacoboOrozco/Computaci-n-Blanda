/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author orozc
 */
public class Farinngitis {
    float fiebre_farinngitis = 0.3f;
    float malestar_farinngitis = 0.2f;
    float dolor_garganta_farinngitis = 0.7f;
    
}
