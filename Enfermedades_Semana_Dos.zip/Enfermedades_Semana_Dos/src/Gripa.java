/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author orozc
 */
public class Gripa {
    float fiebre_gripa = 0.3f;
    float tos_gripa = 0.5f;
    float malestar_gripa = 0.4f;
    float dolor_garganta_gripa = 0.2f; 
    
}
