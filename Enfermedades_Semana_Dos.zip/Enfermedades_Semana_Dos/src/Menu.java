
import java.util.Scanner; 
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author orozc
 */
public class Menu {
    Farinngitis farinngitis = new Farinngitis();
    Gripa gripa = new Gripa();
    
    float total_farinngitis = 0.0f;
    float total_gripa = 0.0f;
    

    public void menu_gripa(){
        
        Scanner sn = new Scanner(System.in);
        int opcion;
        boolean salir = false;
    
        while (!salir){
            System.out.println("1. Fiebre");
            System.out.println("2. Tos");
            System.out.println("3. Malestar");
            System.out.println("4. Dolor De Garganta");
            System.out.println("5. Calcular Probabilidades");
            System.out.println("6. Salir");
            
            System.out.println("Seleccione los sintomas que esta experimentando");
            opcion = sn.nextInt();
            
            switch(opcion){
                case 1 : 
                    float fiebre_far = farinngitis.fiebre_farinngitis;
                    total_farinngitis = total_farinngitis + (1.0f - total_farinngitis) * fiebre_far;
                    float fiebre_gripa = gripa.fiebre_gripa;
                    total_gripa = total_gripa + (1.0f - total_gripa) * fiebre_gripa;
                    
                    break;
                case 2:
                    float tos_far = 0.0f;
                    float tos_gripa = gripa.tos_gripa;
                    total_gripa = total_gripa + (1.0f - total_gripa) * tos_gripa;
                    
                    break;
                case 3:
                    float malestar_far = farinngitis.malestar_farinngitis;
                    total_farinngitis = total_farinngitis + (1.0f - total_farinngitis) * malestar_far;
                    float malestar_gripa = gripa.malestar_gripa;
                    total_gripa = total_gripa + (1.0f - total_gripa) * malestar_gripa;
                   
                    break;
                case 4:
                    float dolor_garganta_far = farinngitis.dolor_garganta_farinngitis;
                    total_farinngitis = total_farinngitis + (1.0f - total_farinngitis) * dolor_garganta_far;
                    float dolor_garganta_gripa = gripa.dolor_garganta_gripa;
                    total_gripa = total_gripa + (1.0f - total_gripa) * dolor_garganta_gripa;
                    break;
                case 5:
                    System.out.println("La probabilidad para las enfermedades se lista a continuacón: ");
                    total_gripa = total_gripa * 100.0f;
                    System.out.println("La probabilidad de que el paciente sufra de gripa es de: " + total_gripa + "%");
                    total_farinngitis = total_farinngitis * 100.0f;
                    System.out.println("La probabilidad de que el paciente sufra de farinngitis es de: " + total_farinngitis + "%");
                case 6:
                    salir = true;
                    
                    
            }
            
        }
        
    }

}
